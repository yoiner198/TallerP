﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, List<double>> paises = new Dictionary<string, List<double>>();

            // Cargar los datos de los países por teclado
            Console.WriteLine("Ingrese los datos de los países:");
            for (int i = 1; i <= 4; i++)
            {
                Console.WriteLine("País {0}:", i);
                Console.Write("Nombre: ");
                string nombre = Console.ReadLine();

                Console.Write("Temperatura media del primer mes: ");
                double temp1 = double.Parse(Console.ReadLine());

                Console.Write("Temperatura media del segundo mes: ");
                double temp2 = double.Parse(Console.ReadLine());

                Console.Write("Temperatura media del tercer mes: ");
                double temp3 = double.Parse(Console.ReadLine());

                paises[nombre] = new List<double> { temp1, temp2, temp3 };
            }

            // Imprimir los datos de los países
            Console.WriteLine("\nDatos de los países:");
            foreach (KeyValuePair<string, List<double>> pais in paises)
            {
                Console.WriteLine("{0} - Temperaturas: {1}, {2}, {3}", pais.Key, pais.Value[0], pais.Value[1], pais.Value[2]);
            }

            // Calcular las temperaturas medias trimestrales de los países
            Dictionary<string, double> mediasTrimestrales = new Dictionary<string, double>();
            foreach (KeyValuePair<string, List<double>> pais in paises)
            {
                double media = (pais.Value[0] + pais.Value[1] + pais.Value[2]) / 3;
                mediasTrimestrales[pais.Key] = media;
            }

            // Imprimir las temperaturas medias trimestrales de los países
            Console.WriteLine("\nTemperaturas medias trimestrales:");
            foreach (KeyValuePair<string, double> pais in mediasTrimestrales)
            {
                Console.WriteLine("{0} - Temperatura media trimestral: {1}", pais.Key, pais.Value);
            }

            // Encontrar el país con la temperatura media trimestral mayor
            double maxMedia = double.MinValue;
            string maxPais = "";
            foreach (KeyValuePair<string, double> pais in mediasTrimestrales)
            {
                if (pais.Value > maxMedia)
                {
                    maxMedia = pais.Value;
                    maxPais = pais.Key;
                }
            }

            Console.WriteLine("\nPaís con la temperatura media trimestral mayor: {0}", maxPais);
            Console.ReadKey();
        }
    }
}
