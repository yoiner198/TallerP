﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Curso a = new Curso();
            a.cargaN();
            a.imprimir();
            Console.ReadKey();
            
        }
    }
    public class Curso
    {
        double[] cursoB = new double[5];
        double promA;
        double[] cursoA = new double[5];
        double promB;

        public void cargaN()
        {
            for(int i = 0; i < cursoA.Length; i++)
            {
                Console.WriteLine($"Ingrese la nota {i+1} de ambos cursos: ");
                Console.WriteLine("Curso A: ");
                cursoA[i] = double.Parse(Console.ReadLine());
                promA += cursoA[i];
                Console.WriteLine("Curso B: ");
                cursoB[i] = double.Parse(Console.ReadLine());
                promB += cursoB[i];
            }
            
        }
        public void imprimir()
        {
            promA = promA / 5;
            promB = promB / 5;
            Console.WriteLine($"El promedio del curso A es: {promA}");
            Console.WriteLine($"El promedio del curso B es: {promB}");


            if (promA > promB)
            {
                Console.WriteLine($"El curso con el promedio de notas mayor es el curso A con: {promA} de nota promedio"); 
                
            }
            else
            {
                Console.WriteLine($"El curso con el promedio de notas mayor es el curso B con: {promB} de nota promedio");
            }
        }


    }
}
