﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AdministradorInasistencias administrador = new AdministradorInasistencias();
            administrador.CargarInasistencias();
            administrador.MostrarInasistencias();
            administrador.EmpleadoConMenosInasistencias();
            Console.ReadKey();
        }
        class AdministradorInasistencias
        {
            private string[] empleados = new string[3];
            private int[][] inasistencias = new int[3][];

            public AdministradorInasistencias()
            {
                empleados[0] = "Empleado 1";
                empleados[1] = "Empleado 2";
                empleados[2] = "Empleado 3";
                inasistencias[0] = new int[31];
                inasistencias[1] = new int[28];
                inasistencias[2] = new int[30];
            }

            public void CargarInasistencias()
            {
                for (int i = 0; i < 3; i++)
                {
                    Console.WriteLine("Ingrese las inasistencias para {0}:", empleados[i]);
                    for (int j = 0; j < inasistencias[i].Length; j++)
                    {
                        Console.Write("Ingrese el número de día que faltó (-1 para terminar): ");
                        int dia = int.Parse(Console.ReadLine());
                        if (dia == -1)
                        {
                            break;
                        }
                        inasistencias[i][j] = dia;
                    }
                }
            }

            public void MostrarInasistencias()
            {
                Console.WriteLine("Inasistencias:");
                for (int i = 0; i < 3; i++)
                {
                    int total = 0;
                    Console.Write("{0}: ", empleados[i]);
                    for (int j = 0; j < inasistencias[i].Length; j++)
                    {
                        if (inasistencias[i][j] != 0)
                        {
                            Console.Write("{0} ", inasistencias[i][j]);
                            total++;
                        }
                    }
                    Console.WriteLine("(Total: {0})", total);
                }
            }

            public void EmpleadoConMenosInasistencias()
            {
                int minInasistencias = inasistencias[0].Length;
                string empleadoConMenosInasistencias = empleados[0];
                for (int i = 1; i < 3; i++)
                {
                    int inasistenciasEmpleado = 0;
                    for (int j = 0; j < inasistencias[i].Length; j++)
                    {
                        if (inasistencias[i][j] != 0)
                        {
                            inasistenciasEmpleado++;
                        }
                    }
                    if (inasistenciasEmpleado < minInasistencias)
                    {
                        minInasistencias = inasistenciasEmpleado;
                        empleadoConMenosInasistencias = empleados[i];
                    }
                }
                Console.WriteLine("El empleado con menos inasistencias es {0} (Total: {1})", empleadoConMenosInasistencias, minInasistencias);
            }
        }
    }
}
