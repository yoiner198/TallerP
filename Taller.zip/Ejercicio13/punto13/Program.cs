﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el número de filas (n): ");
            int n = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el número de columnas (m): ");
            int m = int.Parse(Console.ReadLine());

            int[,] matriz = new int[n, m];

            // Llenar la matriz con valores ingresados por el usuario
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write("Ingrese el valor para la posición [{0},{1}]: ", i, j);
                    matriz[i, j] = int.Parse(Console.ReadLine());
                }
            }

            // Imprimir los cuatro vértices de la matriz
            Console.WriteLine("Vértices de la matriz:");
            Console.WriteLine("mat[0][0] = {0}", matriz[0, 0]);
            Console.WriteLine("mat[0][{0}] = {1}", m - 1, matriz[0, m - 1]);
            Console.WriteLine("mat[{0}][0] = {1}", n - 1, matriz[n - 1, 0]);
            Console.WriteLine("mat[{0}][{1}] = {2}", n - 1, m - 1, matriz[n - 1, m - 1]);
            Console.ReadKey();
        }
    }
}
