﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] paises = { "Portugal", "Brasil", "Chile", "Colombia", "Uruguay" };
            int[] habitantes = { 2500000, 2138000, 5000000, 7800000, 4000000 };

            // Ordenar alfabéticamente
            Array.Sort(paises, habitantes);
            Console.WriteLine("Ordenado alfabéticamente:");
            for (int i = 0; i < paises.Length; i++)
            {
                Console.WriteLine("{0}: {1}", paises[i], habitantes[i]);
            }

            // Ordenar por cantidad de habitantes
            Array.Sort(habitantes, paises);
            Array.Reverse(habitantes);
            Array.Reverse(paises);
            Console.WriteLine("\nOrdenado por cantidad de habitantes:");
            for (int i = 0; i < paises.Length; i++)
            {
                Console.WriteLine("{0}: {1}", paises[i], habitantes[i]);
            }
            Console.ReadKey();
        }
    }
}
