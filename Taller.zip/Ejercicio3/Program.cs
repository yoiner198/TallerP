﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Vector v = new Vector();
            v.CargaAV();
            v.ImprV();
            Console.ReadKey();
        }
    }

    class Vector
    {
        int[] vector = new int[8];
        int acumulado = 0;
        int acumuladoM36 = 0;
        int contM50;
        public void CargaAV()
        {
            for (int i = 0; i < vector.Length; i++)
            {
                Console.WriteLine($"Ingrese el elemento No {i+1}:");
                vector[i] = int.Parse(Console.ReadLine());
                acumulado += vector[i];
                if (vector[i] > 36)
                {
                    acumuladoM36 += vector[i];
                    if (vector[i] > 50)
                    {
                        contM50++;
                    }
                }
            }
        }
        public void ImprV() 
        {
            Console.WriteLine($"El valor acumulado de todos los elementos del vector es {acumulado}");
            Console.WriteLine($"El valor acumulado de los elementos del vector que sean mayores a 36 es {acumuladoM36}");
            Console.WriteLine($"La cantidad de valores mayores a 50 es {contM50}");

            
        }

    }
}
