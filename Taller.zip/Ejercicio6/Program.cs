﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Vector vector = new Vector();
            vector.cargaV();
            Console.Write("Vector: ");
            vector.imprimirO();
            Console.WriteLine();
            vector.ordenaV();
            Console.Write("Vector Ordenado: ");
            vector.imprimirO();
            Console.ReadKey();

        }
    }
    class Vector
    {
        int[] vector = new int[10];

        public void cargaV()
        {
            for (int i = 0; i < vector.Length; i++)
            {
                Console.WriteLine($"Ingrese el valor N {i+1} del vector: ");
                vector[i] = int.Parse(Console.ReadLine());
            }
        }

        public void ordenaV()
        {
            int a = 0;
            for(int j = 1; j < vector.Length; j++)
            {
                for (int i =0; i < vector.Length - j; i++)
                {
                    if (vector[i] > vector[i+1])
                    {
                        a = vector[i];
                        vector[i] = vector[i + 1];
                        vector[i + 1] = a;
                    }
                }
            }
        }
        public void imprimirO()
        {
            Console.Write("[");
            for (int i = 0; i < vector.Length; i++)
            {
                Console.Write($" {vector[i]},");
            }
            Console.Write("]");
        }
    }
}
