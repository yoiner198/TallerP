﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace PuntoN7
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Vector vector = new Vector();
            vector.IngresoDatos();
            vector.SumaDatos();

            Console.ReadLine();
        }

       }
    public class Vector
    {
        private int[] datos;

        public void IngresoDatos()
        {
            Console.Write("Ingrese el tamaño del vector: ");
            int n = int.Parse(Console.ReadLine());

            datos = new int[n];

            Console.WriteLine($"Ingrese los {n} valores del vector:");
            for (int i = 0; i < datos.Length; i++)
            {
                Console.Write($"Valor {i + 1}: ");
                datos[i] = int.Parse(Console.ReadLine());
            }
        }

        public void SumaDatos()
        {
            int suma = 0;

            for (int i = 0; i < datos.Length; i++)
            {
                suma += datos[i];
            }

            Console.WriteLine($"La suma de todos los elementos del vector es: {suma}");
        }
    }
}
