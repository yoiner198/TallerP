﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Puntonum8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.Write("Ingrese el tamaño del vector: ");
            n = int.Parse(Console.ReadLine());

            Vector v = new Vector(n);
            v.CargarDatos();
            v.DatoMenor();

            Console.ReadLine();
            Console.ReadKey();
        }
    }
    public class Vector
    {
        public  int[] vector;
        public int n;

        public Vector(int n)
        {
            this.n = n;
            vector = new int[n];
        }

        public void CargarDatos()
        {
            for (int i = 0; i < n; i++)
            {
                Console.Write("Ingrese el elemento {0}: ", i + 1);
                vector[i] = int.Parse(Console.ReadLine());
            }
        }

        public void DatoMenor()
        {
            int menor = vector[0];
            for (int i = 1; i < n; i++)
            {
                if (vector[i] < menor)
                {
                    menor = vector[i];
                }
            }
            Console.WriteLine("El elemento menor es: {0}", menor);

            bool repetido = false;
            for (int i = 0; i < n; i++)
            {
                if (vector[i] == menor && i != Array.IndexOf(vector, menor, i + 1))
                {
                    repetido = true;
                    break;
                }
            }
            if (repetido)
            {
                Console.WriteLine("El elemento menor se repite dentro del vector.");
            }
        }
    }
}