﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Vectores v = new Vectores();
            v.cargaV();
            v.imprimirS();

            Console.ReadKey();
        }
    }
    class Vectores
    {
        int[] vector2 = new int[4];
        int[] vector1 = new int[4];
        int[] suma = new int[4];

        public void cargaV()
        {
            

            for (int i = 0; i < vector1.Length; i++)
            {
                Console.WriteLine($"Ingrese el valor {i+1} de ambos vectores: ");
                Console.Write("Vector 1: ");
                vector1[i] = int.Parse(Console.ReadLine());
                Console.Write("Vector 2: ");
                vector2[i] = int.Parse(Console.ReadLine());
                suma[i] = vector1[i] + vector2[i];

            }
            
        } 
        public void imprimirS() 
        {
            Console.WriteLine("La suma de los dos vectores es:");
            for (int i = 0; i < suma.Length; i++)
            {
                Console.WriteLine($"Valor {i + 1}: {suma[i]}");
            }
        }
    }
}
