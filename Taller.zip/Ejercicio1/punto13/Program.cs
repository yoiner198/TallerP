﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Empleado empleado1 = new Empleado();

            empleado1.CargarDatos();
            empleado1.ImprimirDatos();
            empleado1.PagarImpuestos();
            Console.ReadKey();
        }
    }

    public class Empleado
    {
        // atributos
        private string nombre;
        private double sueldo;

        // métodos
        public void CargarDatos()
        {
            Console.Write("Ingrese el nombre del empleado: ");
            nombre = Console.ReadLine();

            Console.Write("Ingrese el sueldo del empleado: ");
            sueldo = double.Parse(Console.ReadLine());
        }

        public void ImprimirDatos()
        {
            Console.WriteLine("Empleado: {0}", nombre);
            Console.WriteLine("Sueldo: {0}", sueldo);
        }

        public void PagarImpuestos()
        {
            if (sueldo > 3000)
            {
                Console.WriteLine("{0} debe pagar impuestos", nombre);
            }
            else
            {
                Console.WriteLine("{0} no debe pagar impuestos", nombre);
            }
        }
    }

}
