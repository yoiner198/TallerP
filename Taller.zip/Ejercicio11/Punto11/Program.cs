﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] matriz = new int[2, 5];

            // Cargar la matriz por columna
            for (int j = 0; j < 5; j++)
            {
                Console.WriteLine("Ingresar valores de la columna {0}", j + 1);
                for (int i = 0; i < 2; i++)
                {
                    Console.Write("Fila {0}: ", i + 1);
                    matriz[i, j] = int.Parse(Console.ReadLine());
                }
            }

            // Imprimir la matriz
            Console.WriteLine("Matriz:");
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Console.Write("{0}\t", matriz[i, j]);
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
