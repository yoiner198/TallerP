﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejericio9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el tamaño del vector: ");
            int n = int.Parse(Console.ReadLine());

            int[] vector = new int[n];

            for (int i = 0; i < n; i++)
            {
                Console.Write($"Ingrese el elemento {i + 1}: ");
                vector[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Vector original:");
            ImprimirVector(vector);

            OrdenarPorSeleccion(vector);

            Console.WriteLine("Vector ordenado:");
            ImprimirVector(vector);
        }

        static void OrdenarPorSeleccion(int[] vector)
        {
            int n = vector.Length;
            for (int i = 0; i < n - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < n; j++)
                {
                    if (vector[j] < vector[minIndex])
                    {
                        minIndex = j;
                    }
                }
                if (minIndex != i)
                {

                    int temp = vector[i];
                    vector[i] = vector[minIndex];
                    vector[minIndex] = temp;
                }
            }
        }

        static void ImprimirVector(int[] vector)
        {
            foreach (int valor in vector)
            {
                Console.Write(valor + " ");
            }
            Console.WriteLine();
        }
    }
}