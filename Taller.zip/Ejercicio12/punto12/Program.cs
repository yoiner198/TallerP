﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el número de filas (n): ");
            int n = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el número de columnas (m): ");
            int m = int.Parse(Console.ReadLine());

            int[,] matriz = new int[n, m];

            // Llenar la matriz con valores ingresados por el usuario
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write("Ingrese el valor para la posición [{0},{1}]: ", i, j);
                    matriz[i, j] = int.Parse(Console.ReadLine());
                }
            }

            // Intercambiar la primera fila con la segunda
            for (int j = 0; j < m; j++)
            {
                int temp = matriz[0, j];
                matriz[0, j] = matriz[1, j];
                matriz[1, j] = temp;
            }

            // Imprimir la matriz resultante
            Console.WriteLine("Matriz resultante:");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write("{0} ", matriz[i, j]);
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
