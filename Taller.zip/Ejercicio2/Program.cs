﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{

    internal class Program
    {
        static void Main(string[] args)
        {
            Operaciones si = new Operaciones();
            si.cargaD();
            si.sumaD();
            si.restaD();
            si.multiplicacionD();
            si.divisionD();
            Console.ReadKey();
        }
    }
    public class Operaciones

    {
        double num1 =0, num2=0;
        public void cargaD()
        {
            Console.WriteLine("Ingrese un numero: ");
            num1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese un numero: ");
            num2 = double.Parse(Console.ReadLine());
        }
        public void sumaD()
        {
            Console.WriteLine("El resultado de la suma es: " + (num1 + num2));
        }
        public void restaD()
        {
            Console.WriteLine("El resultado de la resta es: " + (num1 - num2));
        }
        public void multiplicacionD()
        {
            Console.WriteLine("El resultado de la multiplicacion es: " + (num1 * num2));
        }
        public void divisionD()
        {
            Console.WriteLine("El resultado de la division es: " + (num1 / num2));
        }
    }
}
