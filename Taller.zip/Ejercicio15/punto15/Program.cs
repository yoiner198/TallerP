﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MatrizIrregular matriz = new MatrizIrregular();
            matriz.CargarPorTeclado();
            matriz.Imprimir();
            Console.ReadKey();

        }
        public class MatrizIrregular
        {
            private int[][] matriz = new int[5][];

            public void MatrizIrregularpoi()
            {
                for (int i = 0; i < 5; i++)
                {
                    matriz[i] = new int[i + 1];
                }
            }

            public void CargarPorTeclado()
            {
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j <= i; j++)
                    {
                        Console.Write("Ingrese el valor para la posición [{0}][{1}]: ", i, j);
                        matriz[i][j] = int.Parse(Console.ReadLine());
                    }
                }
            }

            public void Imprimir()
            {
                Console.WriteLine("Matriz irregular:");
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j <= i; j++)
                    {
                        Console.Write("{0} ", matriz[i][j]);
                    }
                    Console.WriteLine();
                }
            }
        }
    }
}

        

    
